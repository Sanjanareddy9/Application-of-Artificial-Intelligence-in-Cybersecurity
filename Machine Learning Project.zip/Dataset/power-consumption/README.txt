Attribute Information:

Date Time: Each ten minutes. 
Temperature: Weather Temperature of the city. 
Humidity: Weather Humidity of the city. 
Wind Speed of the city. 
power consumption of an area of the city. 